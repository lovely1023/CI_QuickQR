<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'quickqr';
$config['db']['user'] = 'root';
$config['db']['pass'] = '';
$config['db']['pre'] = 'qr_';
$config['db']['port'] = '';

$config['version'] = '5.8';
?>